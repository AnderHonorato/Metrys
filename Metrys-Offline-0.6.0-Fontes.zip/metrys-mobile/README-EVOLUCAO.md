# Metrys Offline 0.6.0-dev | implementação parcial

**Não é um APK pronto.** Este diretório contém evolução de código sobre a fonte 0.5.0 fornecida no pacote de referência. O APK 0.5.0 original continua intacto no arquivo anexado pelo usuário. Não instale uma nova assinatura sobre o aplicativo com dados existentes nem o desinstale.

## Funcionalidades desenvolvidas em código

- `BancoMetrys.java`: SQLite local, chaves estrangeiras, índices, WAL e esquema para projetos, conversas, mensagens, memórias explícitas, anexos, personalização e trabalhos. Importação binária original transacional e idempotente, sem apagar `historico.bin`.
- `ServicoOffline.java`: passa a usar o banco, incorpora personalização e memória explicitamente salva ao prompt local, e expõe operações de projetos/conversas.
- `TelaOffline.java`: projetos, criação/renomeação/movimentação/arquivo/restauração, busca, lembranças, personalização, rascunhos por conversa, editor expandido, prévia de arquivo textual SAF, ditado do serviço de voz Android e Work manual de arquivos.
- `EditorArquivos.java`: leitura/escrita em URI SAF com verificação SHA-256 antes da edição, backup privado do texto anterior e limite de 256 KB.
- `PermissoesMetrys.java`: perfis Solicitar/Apenas texto/Acesso total sob escopo SAF. O modo Apenas texto barra o serviço de escrita. Mesmo em Acesso total, é preciso selecionar o documento no Android e confirmar alterações.
- ABI ARM64 JNI, APK base legado, identidade e fallback do modelo foram preservados no pacote de fontes.

## Testar

```bash
python3 scripts/testar-evolucao.py
```

Os testes executados **não** compilam o Android. Para compilar requer SDK platform36, build-tools36, JDK17 e as ferramentas listadas no `README.md` legado. A versão de desenvolvimento usa `versionCode=9`. Exemplo de comando após instalação dos binários:

```bash
python3 scripts/compilar-apk.py --ferramentas /pasta/ferramentas
```

Esse comando **não foi executado com êxito nesta sessão**. Ele gera uma assinatura nova quando não há chave anterior, portanto não garante substituição do APK 0.5 instalado. A chave original não foi fornecida. Só instalar após verificar continuidade de assinatura/ID ou gerar uma variante paralela devidamente validada. O app mantém instrução base de modelo Qwen2.5-Coder-1.5B e **não** treina pesos com as conversas.

## Limites ainda abertos

- Nada foi testado com interface real, no emulador ou no Galaxy A35. Java semanticamente compatível com Android e execução de JNI precisam de validação.
- Busca usa `LIKE` parametrizado e escapado, ainda sem índice FTS. Memória não extrai fatos automaticamente, só recupera lembranças cadastradas expressamente. Referências de memória na inferência são IDs, não links navegáveis ainda.
- Work não é agente autônomo: é editor manual de texto via SAF, com metas simples persistentes; sem shell/sandbox de execução, diffs nem restauração visual de revisões. A operação SAF pode não ser atômica no provedor escolhido.
- Ditado solicita preferência offline, mas depende de serviço de reconhecimento do sistema e não garante execução inteiramente sem internet. Áudio de pressão longa e gravações persistentes não estão implementados.
- OAuth GitHub/Drive, WhatsApp Business, plugins reais, multimodal e troca de GGUF não implementados.
- Arquivo fonte da instalação antiga é parcial: mantém DEX legados preservados e biblioteca JNI, mas sua compatibilidade após reempacotamento exige build e smoke-test.

Leia `CHECKLIST.md` e `docs/` para pendências detalhadas. Nenhuma chave privada, token ou senha deve entrar no ZIP/commit.

**Recursos tipográficos:** os arquivos de fonte do pacote inicial foram mantidos apenas na árvore de trabalho local e não são redistribuídos no novo ZIP. Para reconstituir a aparência exata da versão 0.5.0, reutilize os recursos de fonte de seu ZIP original `Metrys-Offline-Fontes-0.5.0.zip` em `android/res/font/` antes de compilar. A interface inclui fontes padrão como fallback.
