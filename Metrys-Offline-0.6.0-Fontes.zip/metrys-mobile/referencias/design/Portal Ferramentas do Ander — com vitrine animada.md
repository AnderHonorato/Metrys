[Pular para o conteúdo](#conteudo)

[A **Ferramentas**por Ander](./)

Tudo no mesmo lugar

# Ferramentas úteis sem caça ao botão certo.

Busque, abra, volte ao que usou recentemente e descubra ferramentas relacionadas. As funções públicas continuam acessíveis sem cadastro.

O que você precisa fazer?

Retomar

## Vistos recentemente

Organizado de verdade

## Categorias

Catálogo

## Ferramentas disponíveis

Nenhuma ferramenta combina com essa busca.

Sem manual de 80 páginas

## Perguntas frequentes

Preciso criar conta?

Não para usar as ferramentas públicas. A conta serve para sincronizar histórico, preferências e downloads entre aparelhos quando o backend estiver conectado.

Meus arquivos são enviados para algum servidor?

As ferramentas atuais foram projetadas para processar no navegador sempre que possível. Cada ferramenta deve informar quando um recurso exigir servidor.

Onde ficam os downloads?

No modo local, o portal registra apenas nome, ferramenta e data no seu navegador. Com conta conectada, o histórico poderá ser sincronizado via banco.

Como peço ajuda numa ferramenta?

Use o botão Ajuda no topo. O painel explica o fluxo básico e mostra atalhos para as categorias.

Ferramentas do Ander · 2026 Feito para ser simples antes de ser enfeitado.

Primeira visita Bem-vindo ao portal Você pode começar pela busca, escolher uma categoria ou voltar às ferramentas vistas recentemente. Nada básico fica bloqueado por login. Ajuda rápida Como usar Busque pelo que quer fazer. Abra uma ferramenta e conclua o processo. Ao voltar, ela aparece em Vistos recentemente. Ferramentas da mesma categoria ficam próximas para facilitar comparação. Atalho: pressione / para focar a busca. Conta Entrar e sincronizar Os botões abaixo já usam as rotas previstas do backend. Enquanto as credenciais OAuth não forem configuradas, o portal continua funcionando em modo local. Nenhum provedor é simulado. Sem configuração real, o portal informa que a integração ainda não está ativa.