# CHECKLIST INICIAL — METRYS (PARA EXECUÇÃO PELO ORQUESTRADOR)

**Propósito:** checklist de implementação parcial da base 0.6.0-dev. Nenhum recurso é considerado validado no Android sem compilação e dispositivo. As alterações realizadas estão documentadas em docs/; a validação executada nesta sessão foi apenas estática e de testes Java/SQLite.

**Legenda:** `[x]` evidência conferida no contexto deste pacote; `[~]` em andamento; `[ ]` falta executar; `[!]` problema/limitação a resolver. Uma linha nunca vira `[x]` apenas por existir código.

## A. Preparação deste prompt (não é implantação no app)

- [x] Solicitações funcionais e padrão de orquestração consolidados no prompt mestre desta entrega.
- [x] Pacote de fontes 0.5.0 inspecionado em nível de estrutura, README, manifesto, scripts e classes de histórico/motor.
- [x] Referências locais de design inspecionadas e diferenciadas da identidade do Metrys.
- [x] Prompt universal redigido sem exigir especificamente GPT ou Claude.
- [!] Artefato online `claude.ai/artifact/KcYWWFJtjacSk31aibLUca` exige login e **não pôde ser lido**; caso tenha requisitos exclusivos, disponibilizar exportação ao executor.
- [ ] Executar auditoria, compilar ou modificar o app: **esta entrega é o prompt, não uma nova versão APK**.

## B. Onda 0 — Auditoria e preservação

- [x] 001 Inventariar pacote de fontes, APK e assinatura com hashes.
- [~] 002 Conferir Git/branches e preparar branch isolada.
- [~] 003 Criar backup seguro e provar restauração.
- [~] 004 Reproduzir compilação da base 0.5.0.
- [x] 005 Verificar packageId, versionCode, minSdk e ABI.
- [~] 006 Verificar certificado e estratégia de atualização.
- [x] 007 Mapear funcionalidades legadas e regressões.
- [x] 008 Criar `docs/auditoria-inicial.md`.
- [x] 009 Criar `docs/contratos.md`, `docs/decisoes.md`.
- [x] 010 Criar `.orquestracao/propriedade.json`.
- [x] 011 Criar `docs/matriz-rastreabilidade.md`.
- [~] 012 Definir arquitetura de persistência/segurança/Work.

## C. Onda 1 — Fundação Android e dados

- [~] 013 Implementar SQLite com migrações versionadas e índices.
- [~] 014 Implementar importação de `historico.bin` sem perda.
- [~] 015 Testar importação idempotente.
- [~] 016 Testar falha durante migração e restauração.
- [~] 017 Implementar repositórios e transações atômicas.
- [~] 018 Preservar motor JNI e inferência offline.
- [ ] 019 Definir estados de tarefas e erros traduzíveis.
- [~] 020 Aplicar persistência de personalização e tema.
- [~] 021 Criar testes base e verificadores de propriedade.

## D. Onda 2 — Projetos, chats, memória e personalização

- [~] 022 Criar, renomear, pesquisar e organizar projetos.
- [~] 023 Criar, renomear e mover chats.
- [~] 024 Arquivar/restaurar projetos e chats.
- [~] 025 Excluir projeto mantendo chats.
- [~] 026 Excluir projeto com chats mediante confirmação.
- [~] 027 Configurações → Chats e arquivos com gerenciamento e exclusão seletiva.
- [~] 028 Exportação/importação de histórico, arquivos e backup.
- [~] 029 Indexação de mensagens e busca global SQLite FTS5/fallback.
- [~] 030 Resumos e memórias com origem e data.
- [~] 031 Recuperação interconversas e citações de fonte.
- [ ] 032 Tratamento de contradições e fatos desatualizados.
- [~] 033 Exclusão/edição de memória e limpeza de índices.
- [~] 034 Personalização global aplicada na primeira mensagem.
- [~] 035 Personalização por projeto e precedência documentada.

## E. Onda 2 — Chat e interface

- [~] 036 Agente dedicado de frontend criado e escopo isolado.
- [~] 037 Compositor cresce para cima com limite.
- [~] 038 Scroll interno do compositor ao alcançar limite.
- [ ] 039 Teclado Android/IME sem sobreposição ou salto.
- [~] 040 Expandir/recolher editor em tela cheia sem perder rascunho.
- [~] 041 Rascunhos independentes por conversa.
- [~] 042 Menu + com câmera, fotos e arquivos reais.
- [ ] 043 Menu + com plugins/habilidades e estados reais.
- [ ] 044 Botão de escolha do modelo e modo de inteligência.
- [~] 045 Mensagens em streaming sem travar scroll.
- [~] 046 Estados vazios, erro, carregamento, indisponível, permissão negada.
- [~] 047 Animações Metrys, tema claro/escuro e fontes coerentes.
- [~] 048 UI PT-BR/EN e TalkBack testados.

## F. Onda 2 — Voz, anexos e arquivos

- [~] 049 Microfone de transcrição sempre visível ao lado de Enviar.
- [~] 050 Transcrição PT-BR verdadeira, offline conforme anúncio.
- [~] 051 Texto transcrito aparece para revisão e não é enviado sozinho.
- [ ] 052 Pressão longa do botão Enviar inicia áudio sem enviar texto.
- [ ] 053 Arrastar/cancelar/soltar gravação com estados claros.
- [ ] 054 Reproduzir áudio e persistir anexo.
- [ ] 055 Testar permissão negada/interrupção e pouco espaço.
- [~] 056 Seletor Android de fotos/câmera/arquivos por SAF.
- [~] 057 Previews seguros de texto, código, imagem, PDF e JSON.
- [ ] 058 Edição, diffs, versões, reversão e exportação.

## G. Onda 2 — Work local

- [~] 059 Persistir objetivo, plano, etapas, eventos e status.
- [~] 060 Criar arquivo local via ferramenta executável.
- [~] 061 Editar arquivo previamente criado com evidência.
- [~] 062 Controle de escopo SAF e proteção de caminhos.
- [~] 063 Escrita atômica e cancelamento seguro.
- [~] 064 Retomar trabalho após reinício sem repetir ação concluída.
- [~] 065 Mostrar artefatos, status, logs e próximos passos na UI.
- [~] 066 Separar operações locais das dependentes de rede.

## H. Onda 3 — Modelos e integrações

- [ ] 067 Preservar download e SHA do modelo existente.
- [ ] 068 Catálogo de modelos de tamanhos e quantizações compatíveis.
- [ ] 069 Seleção inicial de modelo com checagem RAM/armazenamento.
- [ ] 070 Alternar modelo, cancelar e fazer fallback seguro.
- [ ] 071 Perfis de inteligência ligados a parâmetros reais.
- [ ] 072 Plugins/habilidades com manifesto, capacidades e estados.
- [ ] 073 OAuth Google Drive e revogação.
- [ ] 074 Drive: listar, baixar, criar/upload e editar arquivo autorizado.
- [ ] 075 OAuth GitHub e revogação.
- [ ] 076 GitHub: listar, ler, branch, editar e commit autorizado.
- [ ] 077 WhatsApp: compartilhamento oficial via Android Sharesheet.
- [ ] 078 WhatsApp Business API: avaliar/implementar só se credenciais e requisitos permitirem.
- [~] 079 Explicitar dependências online sem confundir com inferência local.
- [ ] 080 Tratamento de quota, rede, OAuth expirado e conflito.

## I. Onda 3 — Permissões e segurança

- [~] 081 Perfil padrão “Solicitar permissão”.
- [~] 082 Perfil “Apenas texto” impede execução de ferramenta mutável.
- [~] 083 Perfil “Acesso total” limitado a escopos explicitamente concedidos.
- [~] 084 Confirmação forte para ação destrutiva/publicação.
- [ ] 085 Tokens protegidos no armazenamento local e não incluídos no APK.
- [~] 086 Ações Work isoladas da sandbox Android.
- [ ] 087 Injeções em arquivos/sites não acionam ferramentas.
- [~] 088 Privacidade, licenças, exportar/excluir dados e ausência de rastreadores ocultos.

## J. Onda 4 — Produto, idioma e qualidade

- [~] 089 Paridade de strings PT-BR/EN completa.
- [~] 090 Contraste e tema em todas as telas.
- [ ] 091 Capturas reais de UI em 390 dp e telas maiores.
- [ ] 092 IME, rotação, fonte ampliada e TalkBack.
- [ ] 093 Teste de lista extensa e streaming.
- [ ] 094 Desempenho e consumo de memória do motor local.
- [~] 095 Documentar limitações de funcionalidades multimodais.
- [~] 096 README e documentação de build/testes/instalação.

## K. Onda 5 — Dois críticos

- [ ] 097 Crítico T independente, somente leitura, evidências.
- [ ] 098 Crítico P independente, somente leitura, imagens e fluxos.
- [ ] 099 Ambos revisam os dez tópicos obrigatórios.
- [ ] 100 Debate, réplica e veredito registrados.
- [~] 101 Correções atribuídas aos donos originais.
- [ ] 102 Rodada 2 para correções críticas/altas.

## L. Onda 6 — APK final e entrega

- [ ] 103 Build limpo da versão nova.
- [~] 104 APK ARM64 com biblioteca JNI real.
- [~] 105 Incrementar versionCode sem quebrar package/assinatura.
- [ ] 106 Verificar assinatura e alinhamento.
- [ ] 107 Instalar e abrir no emulador.
- [ ] 108 Instalar e testar em Galaxy A35 físico, se houver acesso; caso contrário `[!]`.
- [ ] 109 Testar memória, projetos, voz, arquivos e Work de ponta a ponta.
- [ ] 110 Testar integrações com autenticações autorizadas; registrar pendência caso não existam.
- [ ] 111 Gerar APK, SHA-256 e relatório de build.
- [~] 112 Gerar fontes sem segredos e README completo.
- [ ] 113 Registrar saída de testes e `git log --oneline -n 10`.
- [ ] 114 Entregar caminhos/links reais, instalação e pendências objetivas.

---

**Revisão inicial:** `[x]` neste documento refere-se apenas à elaboração/inspeção do PROMPT. Nenhum `[x]` acima corresponde a APK novo, implementação de recurso ou teste Android executado. O orquestrador deve validar tudo na sessão de desenvolvimento.

## Evidência real desta execução (23/10/2026)

- `scripts/testar-evolucao.py`: PASS, 12 arquivos Java sem erros de sintaxe; PASS, regressão do `historico.bin`; PASS, DDL SQLite/integraidade/FKs/cascatas; PASS, manifest XML.
- `[~]` = código parcial ou não validado no Android: não equivale a funcionalidade concluída.
- `[!]` Build Android, assinatura, UI instrumentada, voz offline, integrações OAuth e teste Galaxy A35: não executados.
- Integrações remotas, treinamento de pesos e autonomia irrestrita permanecem **não implementados**.
- `docs/debate-criticos.md` é uma análise de riscos interna; nenhum crítico independente foi convocado.
