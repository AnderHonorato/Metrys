#include <jni.h>
#include "llama.h"
#include "utf8_stream.h"
#include <algorithm>
#include <atomic>
#include <climits>
#include <cstdint>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace {
using Modelo=std::unique_ptr<llama_model,decltype(&llama_model_free)>;
using Contexto=std::unique_ptr<llama_context,decltype(&llama_free)>;
using Amostrador=std::unique_ptr<llama_sampler,decltype(&llama_sampler_free)>;
struct Motor {
 std::atomic<bool> cancelado{false};std::mutex trabalho;
 Modelo modelo{nullptr,llama_model_free};Contexto contexto{nullptr,llama_free};
 ~Motor(){contexto.reset();modelo.reset();}
};
std::mutex registroMutex;std::unordered_map<jlong,std::shared_ptr<Motor>> registro;
std::atomic<jlong> proximo{1};std::once_flag iniciado;
std::shared_ptr<Motor> obter(jlong id){std::lock_guard<std::mutex> lock(registroMutex);auto i=registro.find(id);if(i==registro.end())throw std::runtime_error("O motor local foi fechado.");return i->second;}
bool abortar(void *m){return static_cast<Motor*>(m)->cancelado.load(std::memory_order_relaxed);}
bool progresso(float,void *m){return !abortar(m);}
void erro(JNIEnv *env,const std::exception &e){if(env->ExceptionCheck())return;jclass tipo=env->FindClass("java/io/IOException");if(tipo)env->ThrowNew(tipo,e.what());}
void utf8(std::string &s,uint32_t c){
 if(c<0x80)s.push_back(static_cast<char>(c));
 else if(c<0x800){s.push_back(static_cast<char>(0xc0|(c>>6)));s.push_back(static_cast<char>(0x80|(c&63)));}
 else if(c<0x10000){s.push_back(static_cast<char>(0xe0|(c>>12)));s.push_back(static_cast<char>(0x80|((c>>6)&63)));s.push_back(static_cast<char>(0x80|(c&63)));}
 else{s.push_back(static_cast<char>(0xf0|(c>>18)));s.push_back(static_cast<char>(0x80|((c>>12)&63)));s.push_back(static_cast<char>(0x80|((c>>6)&63)));s.push_back(static_cast<char>(0x80|(c&63)));}
}
std::string texto(JNIEnv *env,jstring v){
 if(!v)throw std::runtime_error("O histórico contém texto nulo.");
 const jsize n=env->GetStringLength(v);const jchar *b=env->GetStringChars(v,nullptr);
 if(!b)throw std::runtime_error("Não há memória para ler o texto.");
 std::string s;
 try{for(jsize i=0;i<n;i++){uint32_t c=b[i];if(c>=0xd800&&c<=0xdbff&&i+1<n&&b[i+1]>=0xdc00&&b[i+1]<=0xdfff){c=0x10000+((c-0xd800)<<10)+(b[++i]-0xdc00);}else if(c>=0xd800&&c<=0xdfff)c=0xfffd;utf8(s,c);}}
 catch(...){env->ReleaseStringChars(v,b);throw;}
 env->ReleaseStringChars(v,b);return s;
}
void emitir(JNIEnv *env,jclass classe,jmethodID entregar,jobject saida,const std::string &s){
 if(s.empty())return;
 jbyteArray b=env->NewByteArray(static_cast<jsize>(s.size()));if(!b)throw std::runtime_error("Memória insuficiente para entregar a resposta.");
 env->SetByteArrayRegion(b,0,static_cast<jsize>(s.size()),reinterpret_cast<const jbyte*>(s.data()));
 if(!env->ExceptionCheck())env->CallStaticVoidMethod(classe,entregar,saida,b);
 env->DeleteLocalRef(b);if(env->ExceptionCheck())throw std::runtime_error("A saída interrompeu a resposta.");
}
struct LimparCache {llama_context *ctx; explicit LimparCache(llama_context *c):ctx(c){llama_memory_clear(llama_get_memory(ctx),true);}~LimparCache(){llama_memory_clear(llama_get_memory(ctx),true);}};
std::string formatar(JNIEnv *env,Motor &m,jobjectArray papeis,jobjectArray mensagens){
 const jsize n=env->GetArrayLength(papeis);
 if(n<1||n>256||env->GetArrayLength(mensagens)!=n)throw std::runtime_error("O histórico deve ter de 1 a 256 mensagens e papéis correspondentes.");
 std::vector<std::string> roles,txts;roles.reserve(n);txts.reserve(n);size_t bytes=0;
 for(jsize i=0;i<n;i++){
  jstring r=static_cast<jstring>(env->GetObjectArrayElement(papeis,i));jstring t=static_cast<jstring>(env->GetObjectArrayElement(mensagens,i));
  try{roles.push_back(texto(env,r));txts.push_back(texto(env,t));}catch(...){if(r)env->DeleteLocalRef(r);if(t)env->DeleteLocalRef(t);throw;}
  env->DeleteLocalRef(r);env->DeleteLocalRef(t);
  if(roles.back()!="system"&&roles.back()!="user"&&roles.back()!="assistant")throw std::runtime_error("Papel inválido: use system, user ou assistant.");
  if(txts.back().find('\0')!=std::string::npos)throw std::runtime_error("A mensagem contém um caractere nulo inválido.");
  bytes+=txts.back().size();if(bytes>1024*1024)throw std::runtime_error("Histórico muito grande. Inicie uma nova conversa.");
 }
 if(roles.back()!="user")throw std::runtime_error("O histórico deve terminar com uma mensagem user.");
 std::vector<llama_chat_message> chat;chat.reserve(n);for(jsize i=0;i<n;i++)chat.push_back({roles[i].c_str(),txts[i].c_str()});
 const char *modelo=llama_model_chat_template(m.modelo.get(),nullptr);if(!modelo)throw std::runtime_error("Este GGUF não contém um template de conversa. Use o modelo indicado.");
 int32_t tam=llama_chat_apply_template(modelo,chat.data(),chat.size(),true,nullptr,0);
 if(tam<0)throw std::runtime_error("O template de conversa deste GGUF não é suportado.");
 std::vector<char> b(static_cast<size_t>(tam)+1);
 int32_t usado=llama_chat_apply_template(modelo,chat.data(),chat.size(),true,b.data(),static_cast<int32_t>(b.size()));
 if(usado<0||usado>tam)throw std::runtime_error("Falha ao aplicar o template de conversa.");
 return std::string(b.data(),usado);
}
std::vector<llama_token> tokenizar(const llama_vocab *v,const std::string &s){
 int32_t n=llama_tokenize(v,s.data(),static_cast<int32_t>(s.size()),nullptr,0,true,true);
 if(n==INT32_MIN||n==0)throw std::runtime_error("Falha no tamanho do tokenizador.");
 std::vector<llama_token> tokens(static_cast<size_t>(n<0?-n:n));
 n=llama_tokenize(v,s.data(),static_cast<int32_t>(s.size()),tokens.data(),static_cast<int32_t>(tokens.size()),true,true);
 if(n<0)throw std::runtime_error("Falha ao tokenizar o histórico.");
 tokens.resize(n);return tokens;
}
bool decodificar(Motor &m,llama_token *tokens,int32_t n){
 if(abortar(&m))return false;
 int status=llama_decode(m.contexto.get(),llama_batch_get_one(tokens,n));
 if(status==2&&abortar(&m))return false;
 if(status!=0)throw std::runtime_error("Falha na inferência CPU (código "+std::to_string(status)+"). Reduza o contexto ou recarregue o modelo.");
 return !abortar(&m);
}
}

extern "C" JNIEXPORT jlong JNICALL Java_br_com_anderflow_metrys_offline_MotorLocal_criarNativo(JNIEnv *env,jclass){
 try{std::call_once(iniciado,[]{llama_backend_init();});auto m=std::make_shared<Motor>();jlong id=proximo.fetch_add(1);std::lock_guard<std::mutex> lock(registroMutex);registro.emplace(id,m);return id;}catch(const std::exception&e){erro(env,e);return 0;}
}
extern "C" JNIEXPORT void JNICALL Java_br_com_anderflow_metrys_offline_MotorLocal_carregarNativo(JNIEnv *env,jclass,jlong id,jstring arquivo,jint contexto,jint threads){
 try{
  auto m=obter(id);std::lock_guard<std::mutex> lock(m->trabalho);m->cancelado=false;m->contexto.reset();m->modelo.reset();
  if(contexto<512||contexto>8192||threads<1||threads>8)throw std::runtime_error("Use contexto de 512 a 8192 e de 1 a 8 threads.");
  std::string caminho=texto(env,arquivo);if(caminho.empty()||caminho.find('\0')!=std::string::npos)throw std::runtime_error("Caminho de modelo inválido.");
  auto mp=llama_model_default_params();mp.load_mode=LLAMA_LOAD_MODE_MMAP;mp.n_gpu_layers=0;mp.progress_callback=progresso;mp.progress_callback_user_data=m.get();
  Modelo modelo(llama_model_load_from_file(caminho.c_str(),mp),llama_model_free);
  if(!modelo)throw std::runtime_error(abortar(m.get())?"Carregamento cancelado.":"Não foi possível abrir o GGUF. Confira o download e o espaço livre.");
  auto cp=llama_context_default_params();cp.n_ctx=static_cast<uint32_t>(contexto);cp.n_batch=128;cp.n_ubatch=128;cp.n_threads=threads;cp.n_threads_batch=threads;
  Contexto ctx(llama_init_from_model(modelo.get(),cp),llama_free);if(!ctx)throw std::runtime_error("Não há memória para criar o contexto. Feche outros aplicativos.");
  llama_set_abort_callback(ctx.get(),abortar,m.get());if(abortar(m.get()))throw std::runtime_error("Carregamento cancelado.");
  m->modelo=std::move(modelo);m->contexto=std::move(ctx);
 }catch(const std::exception&e){erro(env,e);}
}
extern "C" JNIEXPORT void JNICALL Java_br_com_anderflow_metrys_offline_MotorLocal_gerarNativo(JNIEnv *env,jclass classe,jlong id,jobjectArray papeis,jobjectArray mensagens,jobject saida,jint maxTokens){
 try{
  auto m=obter(id);std::lock_guard<std::mutex> lock(m->trabalho);
  if(!m->modelo||!m->contexto)throw std::runtime_error("Carregue o modelo antes de gerar.");
  if(!papeis||!mensagens||!saida)throw std::runtime_error("Histórico e saída são obrigatórios.");
  m->cancelado=false;LimparCache limpar(m->contexto.get());auto prompt=formatar(env,*m,papeis,mensagens);
  const auto *vocab=llama_model_get_vocab(m->modelo.get());auto tokens=tokenizar(vocab,prompt);int nctx=static_cast<int>(llama_n_ctx(m->contexto.get()));
  if(maxTokens<1||maxTokens>=nctx)throw std::runtime_error("O limite de geração deve ser positivo e menor que o contexto.");
  int limite=std::min(1536,nctx-maxTokens);if(static_cast<int>(tokens.size())>limite)throw std::runtime_error("Histórico excede o contexto: "+std::to_string(tokens.size())+" tokens; limite "+std::to_string(limite)+". Reduza a mensagem ou inicie uma nova conversa.");
  Amostrador sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()),llama_sampler_free);
  if(!sampler)throw std::runtime_error("Memória insuficiente para o amostrador.");
  llama_sampler_chain_add(sampler.get(),llama_sampler_init_top_k(40));llama_sampler_chain_add(sampler.get(),llama_sampler_init_top_p(.9f,1));llama_sampler_chain_add(sampler.get(),llama_sampler_init_temp(.65f));llama_sampler_chain_add(sampler.get(),llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
  jmethodID entregar=env->GetStaticMethodID(classe,"entregar","(Lbr/com/anderflow/metrys/offline/MotorLocal$Saida;[B)V");if(!entregar)throw std::runtime_error("Método de saída JNI não encontrado.");
  size_t lote=llama_n_batch(m->contexto.get());for(size_t p=0;p<tokens.size();p+=lote){int32_t n=static_cast<int32_t>(std::min(lote,tokens.size()-p));if(!decodificar(*m,tokens.data()+p,n))return;}
  MetrysUtf8 utf;std::vector<char> pedaco(256);
  for(int i=0;i<maxTokens&&!abortar(m.get());i++){
   llama_token token=llama_sampler_sample(sampler.get(),m->contexto.get(),-1);if(llama_vocab_is_eog(vocab,token))break;
   int n=llama_token_to_piece(vocab,token,pedaco.data(),static_cast<int>(pedaco.size()),0,false);
   if(n<0){pedaco.resize(static_cast<size_t>(-n));n=llama_token_to_piece(vocab,token,pedaco.data(),static_cast<int>(pedaco.size()),0,false);}
   if(n<0)throw std::runtime_error("Falha ao decodificar token.");
   emitir(env,classe,entregar,saida,utf.receber(std::string(pedaco.data(),n)));
   if(i+1<maxTokens&&!decodificar(*m,&token,1))return;
  }
  if(!abortar(m.get()))emitir(env,classe,entregar,saida,utf.finalizar());
 }catch(const std::exception&e){erro(env,e);}
}
extern "C" JNIEXPORT void JNICALL Java_br_com_anderflow_metrys_offline_MotorLocal_cancelarNativo(JNIEnv*,jclass,jlong id){try{obter(id)->cancelado=true;}catch(...) {}}
extern "C" JNIEXPORT void JNICALL Java_br_com_anderflow_metrys_offline_MotorLocal_fecharNativo(JNIEnv*,jclass,jlong id){std::lock_guard<std::mutex> lock(registroMutex);registro.erase(id);}
