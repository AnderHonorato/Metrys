# Motor local do Metrys

JNI/llama.cpp CPU, sem dependência de rede em execução. `MotorLocal.java` oferece carregamento, geração com streaming, cancelamento e descarte. Chamadas de carregar/gerar/fechar devem usar um executor serial; `cancelar()` é thread-safe e pode ser chamado pela UI.

llama.cpp está fixado em `620d2225cc436ab0b001e3200e590e3b286ef9ab`. Essa revisão usa `llama_model_params.load_mode`; o código usa MMAP e zero camadas GPU. O contexto recomendado é 2.048, três threads, prompt máximo 1.536 tokens e geração máxima definida pelo aplicativo (384 nesta interface).

O histórico é formatado pelo template contido no modelo. Suporta papéis `system`, `user` e `assistant`, terminando em `user`; no máximo 256 mensagens e 1 MiB de texto. O cache é limpo a cada geração e em qualquer saída por erro/cancelamento. Não há aprendizagem ou alteração dos pesos nesse processo.

O registro JNI usa `shared_ptr` e identificadores opacos, e os recursos do llama.cpp são gerenciados por RAII. Cancelamento usa flag atômica e callback CPU. O wrapper Java serializa carregar/gerar/fechar, permitindo cancelamento simultâneo. Fragmentos de bytes dos tokens são acumulados até formar UTF-8 completo e entregues por `byte[]` ao Java; isso preserva acentos e caracteres suplementares.

## Compilar Android

```sh
bash scripts/compilar-motor.sh
```

Requer SDK com CMake 3.31.6 e NDK r29. Pode definir `FERRAMENTAS`, `ANDROID_SDK_ROOT`, `ANDROID_NDK_HOME`, `LLAMA_SOURCE_DIR`, `CMAKE`, `NINJA` e `BUILD_MOTOR`. O script aceita checkout Git exato ou tarball oficial acompanhado de `METRYS_COMMIT`. Não incluir os diretórios de build no arquivo de fontes.

ARM64 básico (`armv8-a`), sem exigir DOTPROD/i8mm/SVE, STL estática e alinhamento de segmentos 16 KiB. Dependências dinâmicas finais são somente bibliotecas Android do sistema.

## Testar no computador

`verificar_utf8.cpp` testa fragmentação e bytes inválidos. `VerificarMotor.java` executa modelo real pela mesma JNI, verificando streaming, contexto excedido, exceção do callback, cancelamento, segunda mensagem e descarte idempotente. O teste host não valida desempenho nem instalação em Galaxy A35; o ELF Android é compilado separadamente.

As licenças MIT do llama.cpp/ggml devem acompanhar o APK nos assets. A licença Apache-2.0 do modelo Qwen também deve acompanhar sua distribuição.
