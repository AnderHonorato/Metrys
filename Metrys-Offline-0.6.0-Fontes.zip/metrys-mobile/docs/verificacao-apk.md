# Verificação de entrega Android

- Entrada 0.5.0 verificada como ZIP/APK com quatro DEX e biblioteca ARM64. SHA em `sha256-entradas.txt`.
- `libmetrys.so` da fonte original não foi substituída nem relinkada.
- `scripts/compilar-apk.py` adaptado somente para nome de saída 0.6.0-dev; compilação NÃO executada com SDK válido.
- Ambiente: JDK 21, sem Android SDK36, Build Tools, zipalign, apksigner, adb, NDK e emulador. Não houve modo correto de assinar/verificar ou instalar.
- Certificado de atualização não fornecido. Instalar APK de assinatura diferente sob mesmo packageId provoca erro de atualização e NÃO autoriza desinstalar o app anterior.
- **Artefato desta execução = código-fonte parcial e testes, sem APK instalável 0.6.0-dev.**
