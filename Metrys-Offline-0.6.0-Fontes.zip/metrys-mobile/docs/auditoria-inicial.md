# Auditoria inicial | 23/10/2026

## Entradas verificadas

Pacote mestre (inclui referência, APK 0.5.0 e fontes): SHA-256 `fbd933bf93b491d892500f8fe4d0d9bb87861ca32dbaeb6aaaf8856c531889d7`.

APK original Metrys Offline 0.5.0: 3.429.795 bytes; SHA-256 `89018cc8e6950db01b3363616f700db5ba2c97026ba2d2127b76481c5b0d197a`, quatro DEX e `lib/arm64-v8a/libmetrys.so`.

APK legado `Metrys-Mobile-0.4.1.apk`: 1.301.019 bytes; SHA-256 `858caf4b39d8bd77c8bb2d41d7288698ba6021f17a85c8a0f11e33d447be86a4`, três DEX originais.

Motor: `libmetrys.so`, 6.143.960 bytes, SHA-256 `0bbc4b1f616cad4b83fc332041db7fe2fe27af4624282a7d8ba9efd1b2bc373a`.

O código presente no ZIP era uma árvore de fontes sem diretório `.git` e sem arquivos de assinatura privada. Permissões do manifesto: INTERNET, RECORD_AUDIO, serviços foreground e notificações, minSdk 28, targetSdk 34. O original tinha `versionCode=8`; a árvore de trabalho agora declara `versionCode=9` e `versionName=0.6.0-dev`, ainda **sem APK resultante**.

## Componentes preservados

`DownloadModelo.java`, `MotorLocal.java`, `motor_local.cpp`, `llama.cpp` já compilado (`libmetrys.so`), assets do modelo e ícones originais, Fita, três DEX legados, classes de inferência e serviço, fonte e licença.

## Compatibilidade e riscos

1. Histórico legado em `files/conversas/historico.bin` preservado e lido para importação SQLite; sem caminho autorizado para ler armazenamento privado de outro packageId.
2. Instalar sobre a versão antiga depende do **mesmo certificado**, que não acompanha os anexos. Não desinstalar versões com dados.
3. Build Android bloqueado no ambiente: Java 21 presente, sem SDK platform36, BuildTools36, apksigner, zipalign, adb e emulador; obtenção de SDK não viável nesta sessão.
4. Não foi possível validar interface nem invocar JNI no Galaxy A35.
5. A referência `claude.ai/artifact/KcYWWFJtjacSk31aibLUca` não integra os arquivos disponibilizados; dados autenticados não foram afirmados como lidos.

Resultado: **desenvolvimento parcial em fontes com testes locais**, não release instalável.
