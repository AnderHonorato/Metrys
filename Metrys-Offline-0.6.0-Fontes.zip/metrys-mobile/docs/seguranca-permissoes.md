# Segurança e permissões

- Perfil padrão `solicitar`; usuário escolhe cada URI SAF no seletor Android e confirma atualização na tela Work. Mesmo `acesso_total` não amplia permissões para fora do URI selecionado.
- `apenas_texto` faz `PermissoesMetrys.exigirEscrita()` falhar no serviço, e não só desabilita botão.
- Leitura de texto limitada a 256 KB e rejeita NUL/binário; alterações conferem hash antes de gravar; revisão anterior privada salva em UTF-8.
- Tokens OAuth não existem e não foram incluídos. Sem publicação de chave privada. `.gitignore` proíbe assinatura, build e entrega.
- Futuro: backup exportável/restaurável, criptografia em repouso, testes instrumentados de revogação SAF e de injeção de instruções via arquivo externo.
