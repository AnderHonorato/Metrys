# Relatório de entrega parcial | Metrys 0.6.0-dev

- **Resultado:** código-fonte evoluído e testado localmente; sem novo APK.
- **Base:** arquivo de fontes e APK 0.5.0 do usuário; 3 DEX legados do 0.4.1 e lib ARM64 preservados.
- **Novos módulos:** BancoMetrys, EditorArquivos, PermissoesMetrys, alterações em ServicoOffline/EstadoOffline/TelaOffline/IconeAutoral.
- **Funcionalidades de código:** migração idempotente para SQLite, projetos e arquivo, busca simples, memórias voluntárias e personalização, rascunho independente, editor expansível, arquivo SAF com backup/verificação, modo de permissão e ditado opcional Android.
- **Testes locais:** parser Java sem erro, regressão binária Java passou, DDL SQLite e integridade passaram, manifesto lido. Ver `docs/testes-locais.txt`.
- **Bloqueios reais:** sem SDK Android 36/BuildTools, apksigner, certificado de atualização e dispositivo/emulador autorizado; nenhuma compilação/instalação ou medição de inferência.
- **Pendente:** troca de modelos, OCR/PDF, voz offline garantida, áudio longo, Work autônomo, FTS, OAuth Drive/GitHub, WhatsApp API, dois críticos independentes e todos os testes instrumentados.
- **Segurança:** não desinstalar APK antigo nem tentar substituir sem confirmar assinatura.
- **Git local:** branch master da cópia sem histórico Git inicial, commits em `git-historico.txt` no artefato; não enviado ao GitHub.
