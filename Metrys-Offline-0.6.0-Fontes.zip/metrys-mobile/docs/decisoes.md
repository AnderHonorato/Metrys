# Decisões arquiteturais e trade-offs

1. **Evolução incremental.** Preservar DEX legados, motor JNI ARM64 e catálogo de modelo; adicionar Java + SQLite. Substituir a stack por Gradle/Express sem build testado ampliaria riscos.
2. **Banco como fonte de verdade.** `historico.bin` somente importado no primeiro uso, sem exclusão, usando transação e marcador. Todas as conversas novas vivem em SQLite. Mensagens importadas não recebem timestamps históricos porque o binário não os contém; recebem timestamp de migração, sem inventar datas.
3. **Memória baseada em consentimento.** Memórias só entram na tabela quando o usuário as fornece explicitamente, e são injetadas com origem por ID. Não alegar “aprendizado profundo” ou treinamento real de pesos.
4. **Work restrito.** SAF é o único caminho para criar/editar arquivo externo; backups privados e conflito por SHA reduzem dano, mas gravação no provedor pode falhar. Não executar comandos arbitrários.
5. **Permissão backend.** Somente texto barra escrita no serviço de arquivos. Outros modos continuam limitados por seleção SAF e confirmação; nenhum modo dá root, terminal ou acesso irrestrito.
6. **Sem APK sem cadeia confiável.** Recompilar exige ferramentas, assinatura e testes em Android; manter `0.6.0-dev` apenas como código. O certificado privado antigo não veio com anexos.
7. **Sem delegação fictícia.** Nenhum subagente independente foi disponibilizado para executar auditoria paralela; a análise de riscos não equivale ao debate de dois críticos exigido.
