# Desempenho do modelo

Catálogo original mantém Qwen2.5-Coder-1.5B Q4_K_M GGUF externo (1.117.320.768 bytes, SHA declarado no modelo.json); inferência JNI com contexto 2048 e 3 threads na base. **Nenhuma medição de latência/RAM/temperatura realizada nesta execução**. Seleção de modelos maiores, fallback por RAM e benchmark aguardam ambiente Android.
