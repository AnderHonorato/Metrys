# Matriz de rastreabilidade | parcial

| Exigência | Código | Prova nesta sessão | Situação |
|---|---|---|---|
| Manter história 0.5 | BancoMetrys.importarLegado/HistoricoLocal | Teste binário + transação DDL, sem Android | parcial |
| Projetos/chats/arquivos/exclusão | BancoMetrys/ServicoOffline/TelaOffline | Parser Java + DDL | parcial |
| Busca global | BancoMetrys.buscar/TelaOffline | LIKE literal SQLite | parcial, sem FTS |
| Memória explícita | BancoMetrys.salvarMemoria/recuperarMemorias | Código, sem inferência Android | parcial |
| Personalização pré-primeiro envio | ServicoOffline.enviar/instrucaoEfetiva | Código, sem motor Android | parcial |
| Rascunho por chat/editor expandido | TelaOffline | Parser Java | parcial |
| Ditado | TelaOffline/RecognizerIntent | Parser Java | parcial, offline não garantido |
| Criar/editar arquivos em Work | EditorArquivos/TelaOffline | Parser Java | parcial, sem teste SAF |
| Permissão 3 modos | PermissoesMetrys/TelaOffline | Parser Java | parcial, sem teste Android |
| JNI e download existentes | MotorLocal/DownloadModelo/libmetrys.so | SHA e inventário | preservado em fontes |
| Google/GitHub/WhatsApp API | nenhum | nenhum | não implementado |
| Modelos alternativos reais | nenhum | nenhum | não implementado |
| Extração automática de fatos | nenhum | nenhum | não implementado |
| Críticos T/P independentes | nenhum | nenhum | não realizado |
| APK assinado + A35 testado | nenhum | sem SDK/device | bloqueado |
