# Contratos mínimos entre camadas

## Persistência

`BancoMetrys(Context)` é a fonte primária da nova instalação, via SQLiteOpenHelper versão 1, WAL, integridade referencial e transações em operações compostas. `importarLegado(File)` lê sem alterar o original `historico.bin` e marca a importação no banco na mesma transação. Reexecutar não duplica mensagens. Falha de importação impede confirmação do marcador.

`nova()`, `mensagens(id)`, `adicionar(id,papel,texto)`, `conversas()`, `projetos(boolean)`, `moverConversa(id,projeto|null)`, `arquivarConversa`, `arquivarProjeto`, `buscar(termo)`, `salvarMemoria`, `removerMemoria` e `instrucaoEfetiva(conversa)` são chamadas de domínio. Os identificadores são UUIDs, salvo mensagens SQLite autoincrement.

## Estados e modelo

`ServicoOffline` mantém uma fila serial de operações mutáveis e notifica a tela com `EstadoOffline`; o motor `MotorLocal` segue carregado sob demanda e mantém geração cancelável. O texto de sistema inclui instruções globais e por projeto antes da primeira geração e no máximo quatro memórias explícitas recuperadas por termos coincidentes. **Isso não é treinamento de pesos.**

## Arquivos e permissão

`EditorArquivos` aceita apenas `content://` concedido por SAF, no máximo 256 KB de UTF-8. Edição compara SHA-256, cria uma revisão local e só grava se `PermissoesMetrys.exigirEscrita(true)` liberar. Em Solicitar, usuário escolhe o arquivo e confirma. Em Apenas texto, o serviço bloqueia escrita. Em Acesso total, não extrapola os escopos SAF explicitamente concedidos.

## Regras não atendidas

FTS indexado, anexos persistidos em UI, reconhecimento de voz garantidamente offline, áudio gravado, OAuth, execução autônoma de Work, testes de UI e políticas de migração de assinatura: consultar README-EVOLUCAO.md.
