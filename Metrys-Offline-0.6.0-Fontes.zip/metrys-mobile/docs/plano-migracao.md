# Política de preservação

1. Tirar backup de arquivos privados do app antigo usando exportação oferecida no próprio aplicativo, antes de qualquer instalação nova.
2. A migração legada verifica `files/conversas/historico.bin`; se existir, importa conversa e mensagem em transação SQLite e marca `legado_importado` apenas depois de todas as inserções. Nunca apaga o binário.
3. Para uma instalação assinada por outra chave, Android impede a atualização sobre o mesmo packageId. É necessário obter a chave de assinatura anterior ou distribuir variante paralela **com importação autorizada e testada**, jamais recomendar desinstalar para contornar isso.
4. Validar em emulador Android 9+ e no Galaxy A35, inclusive reinício após falha, exclusão, arquivos e modelo 1,12GB, antes de disponibilizar atualização a usuários.
