# Mapa real do aplicativo

- `android/src/.../TelaOffline.java`: interface Android e intents SAF/ditado/edição, coleta consentimento.
- `android/src/.../EstadoOffline.java`: DTO de estado observável, com conversas e projetos.
- `android/src/.../ServicoOffline.java`: fila sequencial, inferência, download, exportação e operações SQL.
- `android/src/.../BancoMetrys.java`: SQLite, migração legada, CRUD, busca LIKE, memórias e metas Work.
- `android/src/.../HistoricoLocal.java`: leitor binário legível e exportável, **somente para migração**; preservado.
- `android/src/.../EditorArquivos.java`: operações de arquivo texto SAF; backup e SHA.
- `android/src/.../PermissoesMetrys.java`: execução guardada por perfil.
- `android/src/.../MotorLocal.java` e `cpp/motor_local.cpp`: JNI/llama; não alterados.
- `android/src/.../DownloadModelo.java`: download com sha e espelho; não alterado.
- `android/src/.../FitaView.java` e `IconeAutoral.java`: identidade e novos desenhos vetoriais, sem emojis de botão.
- `testes/` e `scripts/testar-evolucao.py`: histórico legado, parser Java e contrato estrutural SQLite.
