> **ATENÇÃO | fontes 0.6.0-dev:** esta árvore recebeu alterações não compiladas. Leia [README-EVOLUCAO.md](README-EVOLUCAO.md). O texto abaixo descreve a base 0.5.0 anterior, não um APK novo.

# Metrys Offline 0.5.0

Instalação Android nativa e independente de PC para o chat textual. O APK contém interface e motor ARM64; o GGUF é baixado separadamente quando solicitado. Após esse download o chat, histórico, cópia e exportação funcionam sem internet.

O aplicativo aparece como **Metrys Offline**, ao lado do Metrys atual. A chave privada original não está disponível; portanto não é uma atualização assinada do app instalado. Não desinstale o Metrys atual: seus dados continuam nele. O novo app começa com histórico próprio. Recursos conectados antigos permanecem acessíveis por ícone e aviso, mas continuam exigindo PC/rede e novo pareamento.

Modelo: Qwen2.5-Coder-1.5B-Instruct Q4_K_M pré-treinado, 1.117.320.768 bytes; instrução de identidade Metrys, sem alegar treinamento personalizado. SHA256 cc324af070c2ecbfd324a30884d2f951a7ff756aba85cb811a6ec436933bb046. Contexto 2048, três threads CPU, resposta incremental/cancelável, sem navegação web no chat local.

Download inicial por GitHub com progresso, pausa/retomada quando a origem fornece ETag forte, tratamento de erro e verificação de integridade. Libere ao menos 1,3GB. Espelho privado no Drive dividido em 12 partes pelo limite de transferência do conector: no seletor Android, escolha Google Drive e selecione todas as partes. A importação ordena nomes e verifica o SHA256 completo. Este fallback exige seleção manual e autenticação da conta no Drive, não é download público automático. Também aceita o GGUF completo exato.

Identidade Fita, Lora/Manrope, controles autorais inferiores de48dp sem emojis ou rótulos visuais, leitor de tela e dicas, animação inicial e repouso estático, chat múltiplo e blocos de código. Android9+ ARM64.

Base: Metrys Mobile0.4.1 versionCode7. Os três DEX originais são preservados byte a byte; a descompilação não substitui o código-fonte Kotlin original. Nova superfície em Java/JNI/llama.cpp fixado no commit620d2225cc436ab0b001e3200e590e3b286ef9ab.

Compilar: JDK17, AndroidSDK36/BuildTools36, NDKr29, CMake3.31.6. `bash scripts/compilar-motor.sh` e `python3 scripts/compilar-apk.py --ferramentas /caminho/ferramentas`. Chave própria em android/.assinatura deve ficar fora do repositório e ser guardada em backup privado. O build verifica DEX antigos, recursos, assinatura e alinhamento16KB. Evidências de testes e limitações em docs/. Nenhuma medição no GalaxyA35 físico foi feita nesta sessão.
