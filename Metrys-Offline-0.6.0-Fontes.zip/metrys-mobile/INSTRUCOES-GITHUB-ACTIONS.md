# Metrys 0.6.0-dev no GitHub Actions

1. Faça upload do arquivo **`Metrys-Offline-0.6.0-Fontes.zip`** na raiz de `AnderHonorato/Metrys`, branch `main`, usando **Add file > Upload files > Commit changes**. NÃO envie o ZIP como conteúdo extraído; é só um arquivo.
2. Abra https://github.com/AnderHonorato/Metrys/actions/workflows/gerar-apk-metrys-0.6.yml e abra a execução `Gerar APK Metrys 0.6.0 (prévia)` disparada automaticamente pelo commit. Se não houver execução, use **Run workflow** na branch `main`.
3. Após execução verde, abra **Artifacts** e baixe `Metrys-0.6.0-Previa-Android-ARM64`. Extraia o ZIP e instale o `.apk`.

## Segurança e limitações

- **Prévia separada:** pacote `br.com.anderflow.metrys.offline.previa`, evitando substituir o Metrys antigo e apagar dados.
- **Assinatura efêmera:** nova a cada execução. Para atualizar a prévia posteriormente, será necessário desinstalar a prévia antiga ou configurar um certificado persistente. Isso NÃO afeta o app antigo.
- **Versão em desenvolvimento:** funcionalidades sem teste instrumental podem apresentar falhas. Não remover sua instalação anterior.
- **Nada de senhas no repositório:** uma atualização assinada sobre o APK anterior só será possível com a chave original de assinatura.
- Caso o job falhe, abra o log da etapa vermelha em vez de instalar um APK não validado.
